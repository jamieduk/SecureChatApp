#!/usr/bin/env python3
import os
import sys
import subprocess
import string
import random

bashfile=''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
bashfile='/tmp/'+bashfile+'.sh'

f = open(bashfile, 'w')
s = """#!/bin/bash
# (c) J~NET 2021
# jnet.sytes.net
#
# https://jnet.forumotion.com/t1729-jnet-multi-tool-2021#2677
# https://jnet.forumotion.com/t1744-secure-chat-python3-app#2702
#
port="776"
if [ -f config/port.txt ];
then
    port=`cat config/port.txt`
fi
clear
echo -en "\\e[92mWelcome To J~Net Menu"
echo ""
echo ""
echo "1. Show All Messages"
echo "2. Recieve Message" 
echo "3. Send Message"
echo "4. Calendar"
echo "5. Recieve File"
echo "6. Send File"
echo "7. Setup"
echo "8. View Downloaded File"
echo "9. Remote Shell"
echo "10. Update Alias"
echo "11. Repair A Corrupted Message"
echo "12. Update J~NET Multi Tool 2021"
echo "13. Help"
echo "14. Generate Strong Key"
echo "15. Connect To Secure Multi-Chat"
echo "16. Update Remote Host IP (Add To It)"
echo "17. Replace Remote Host IP List"
echo "18. Monitor Port $port For Connections"
echo "19. Change Port Number"
echo "20. Sticky Chat 2 way Private Chat Menu"
echo "Enter your choice: (Anything else to exit)" 
read n
case $n in
1)
clear
cat config/all_messages.txt | less && python3 menu.py

python3 menu.py ;;
2) python3 secure_recieve_admin.py ;; # Change to secure_recive.py to prevent admin commands!
3) python3 secure_send.py ;;
4) cal 
python3 menu.py;;
5) python3 file_rx.py;;
# send arg here
6) echo "Enter Filename"
   read input
   python3 file_tx.py "$input";;
7) python3 setup.py;;
8) python3 view_file.py;;
9) cd remote && python3 menu.py;;
10) python3 update_alias.py;;
11) python3 repair.py;;
12) python3 update.py;;
13) python3 help.py;;
14) python3 generate_key.py;;
15) python3 MultiChat.py;;
16) python3 update_host.py;;
17) python3 replace_host.py;;
18) python3 monitor.py;;
19) python3 update_port.py;;
20) cd StickyChat && python3 menu.py;;
esac

"""
f.write(s)
f.close()
os.chmod(bashfile, 0o755)
pythoncmd=bashfile
for arg in sys.argv[1:]:
  pythoncmd += ' '+arg
subprocess.call(pythoncmd, shell=True)
