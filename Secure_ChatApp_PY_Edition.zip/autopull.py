#!/usr/bin/env python3
import os
import sys
import subprocess
import string
import random

bashfile=''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
bashfile='/tmp/'+bashfile+'.sh'

f = open(bashfile, 'w')
s = """#!/bin/bash

pwd=`pwd`
echo "$pwd"
#
path=$pwd
cd $path
account="jamieduk"
product="SecureChatApp"
sudo chown -R $USER $path

if cd ../$product; 
then
    #cd ..
    git init .
    git remote add -t \\* -f origin https://github.com/$account/$product.git
    git checkout master
    git pull;
else 
    #git clone https://github.com/$account/$product.git $product;
    git clone https://github.com/$account/$product.git $product;
    #cd $product && sudo rm -rf config && cd ..
fi

echo ""
yes | sudo cp -r $path/$product/* $path
sudo rm -rf $path/$product
sudo chown $USER $path/*
sudo chmod +x $path/*.py
./$path/setup.py
"""
f.write(s)
f.close()
os.chmod(bashfile, 0o755)
bashcmd=bashfile
for arg in sys.argv[1:]:
  bashcmd += ' '+arg
subprocess.call(bashcmd, shell=True)
