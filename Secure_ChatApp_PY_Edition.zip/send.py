#!/usr/bin/env python3
import os
import sys
import subprocess
import string
import random

bashfile=''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
bashfile='/tmp/'+bashfile+'.sh'

f = open(bashfile, 'w')
s = """#!/bin/bash
# (c) J~NET 2021
# jnet.sytes.net
#
# https://jnet.forumotion.com/t1729-jnet-multi-tool-2021#2677
# https://jnet.forumotion.com/t1744-secure-chat-bash-app#2702
#
host_ip=`cat config/remote_host.txt`
port=`cat config/port.txt`
while true;
do
#
input="$@"
if [ -z "$*" ]; then 
    echo "Enter Text To Send: "
    read input; 
fi
#
echo $input > config/msg.txt
#zip -8 -r -q $input uploads/file.zip
clear
echo "Binary Server AKA SENDER"
clear
echo -en "\\e[92mPress Ctrl + C To Confirm Sending New Secure Message! $input \\c"
sleep 0.2
cat config/msg.txt | nc $host_ip $port
count=0
total=34
pstr="[=======================================================================]"

while [ $count -lt $total ]; do
  sleep 0.006 # this is work
  count=$(( $count + 1 ))
  pd=$(( $count * 73 / $total ))
  printf "\\r%3d.%1d%% %.${pd}s" $(( $count * 100 / $total )) $(( ($count * 1000 / $total) % 10 )) $pstr
done
echo "Message Sent!, Please Wait 5 Seconds..."

sleep 5
#exit
# sh send.sh
done
trap "py send.py; exit;" SIGINT SIGTERM;
./send.py
"""
f.write(s)
f.close()
os.chmod(bashfile, 0o755)
bashcmd=bashfile
for arg in sys.argv[1:]:
  bashcmd += ' '+arg
subprocess.call(bashcmd, shell=True)
