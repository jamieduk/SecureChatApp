#!/bin/bash
#
#
#
port=1337
opts="-lvnp"
SSL_crt="server.crt"
SSL_pem="server.pem"
echo -en "\e[92mStarting Listener On $port"
echo ""
echo ""

if [ ! -f server.pem ]
then
    echo "This will now attempt to help you create a key file, fill out the following!..."
    openssl req -x509 -sha256 -nodes -newkey rsa:2048 -days 365 -keyout server.pem -out server.crt
fi

ncat $opts $port --ssl-key $SSL_pem --ssl-cert $SSL_crt

#--ssl-cert             Specify SSL certificate file (cert) for listening
#--ssl-key              Private PEM Key File!


