#!/bin/bash
#
#
host="localhost"
username="" # test@
#
ncat --ssl $username$host 1337
