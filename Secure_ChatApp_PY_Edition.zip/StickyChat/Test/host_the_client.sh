#!/bin/bash
port=1338
echo "Port $port"
tcpserver -v -RHl0 0 $port ./client.sh
