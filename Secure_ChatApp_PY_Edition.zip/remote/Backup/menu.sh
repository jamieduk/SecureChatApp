#!/bin/bash


select fname in *.sh;
do
	echo you picked $fname \($REPLY\)
	bash $fname $myvar	
	break;
done
